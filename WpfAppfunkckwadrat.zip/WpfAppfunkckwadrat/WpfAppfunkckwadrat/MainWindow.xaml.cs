﻿
using System;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WpfAppDelta
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private bool TryReadCoefficient(TextBox textBox, out double value)
        {
            string input = textBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(input))
            {
                value = 0;
                return true;
            }

            bool parsed = double.TryParse(
                input,
                NumberStyles.Float,
                CultureInfo.CurrentCulture,
                out value
            );

            return parsed && !double.IsNaN(value) && !double.IsInfinity(value);
        }

        private string FormatNumber(double number)
        {
            return number.ToString("G", CultureInfo.CurrentCulture);
        }

        private void CalculateButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TryReadCoefficient(txtA, out double a) ||
                !TryReadCoefficient(txtB, out double b) ||
                !TryReadCoefficient(txtC, out double c))
            {
                MessageBox.Show("Podaj poprawne liczby!");
                return;
            }

            if (a == 0)
            {
                MessageBox.Show("Współczynnik a nie może wynosić 0!");
                return;
            }

            double delta = b * b - 4 * a * c;

            if (double.IsNaN(delta) || double.IsInfinity(delta))
            {
                MessageBox.Show("Podane liczby są zbyt duże!");
                return;
            }

            double p = -b / (2 * a);
            double q = -delta / (4 * a);

            if (double.IsNaN(p) || double.IsInfinity(p) ||
                double.IsNaN(q) || double.IsInfinity(q))
            {
                MessageBox.Show("Nie można obliczyć wykresu dla tych wartości.");
                return;
            }

            string roots;

            if (delta > 0)
            {
                double sqrtDelta = Math.Sqrt(delta);

                double x1 = (-b - sqrtDelta) / (2 * a);
                double x2 = (-b + sqrtDelta) / (2 * a);

                roots = "Dwa miejsca zerowe:\n" +
                        "x1 = " + FormatNumber(x1) + "\n" +
                        "x2 = " + FormatNumber(x2);
            }
            else if (delta == 0)
            {
                double x0 = -b / (2 * a);

                roots = "Jedno miejsce zerowe:\n" +
                        "x0 = " + FormatNumber(x0);
            }
            else
            {
                roots = "Brak miejsc zerowych.";
            }

            string direction;

            if (a > 0)
            {
                direction = "Ramiona skierowane do góry.";
            }
            else
            {
                direction = "Ramiona skierowane w dół.";
            }

            string range;

            if (a > 0)
            {
                range = "Zbiór wartości: [" +
                        FormatNumber(q) + "; +∞)";
            }
            else
            {
                range = "Zbiór wartości: (-∞; " +
                        FormatNumber(q) + "]";
            }

            txtResult.Text =
                "Delta = " + FormatNumber(delta) + "\n\n" +
                roots + "\n\n" +
                "Wierzchołek:\n" +
                "W = (" + FormatNumber(p) + "; " +
                FormatNumber(q) + ")\n\n" +
                "Oś symetrii: x = " + FormatNumber(p) + "\n\n" +
                direction + "\n\n" +
                range;

            DrawGraph(a, b, c, delta, p, q);
        }

        private void DrawGraph(double a, double b, double c,
                               double delta, double p, double q)
        {
            graphCanvas.Children.Clear();

            double width = graphCanvas.Width;
            double height = graphCanvas.Height;

            double margin = 35;

            double xRadius = Math.Max(
                5.0,
                Math.Sqrt(Math.Abs(delta)) /
                (2 * Math.Abs(a)) * 1.25
            );

            if (double.IsNaN(xRadius) || double.IsInfinity(xRadius))
            {
                MessageBox.Show("Nie można narysować tego wykresu.");
                return;
            }

            double xMin = p - xRadius;
            double xMax = p + xRadius;

            double yMin = Math.Min(0, q);
            double yMax = Math.Max(0, q);

            for (int i = 0; i <= 200; i++)
            {
                double x = xMin + (xMax - xMin) * i / 200.0;
                double y = a * x * x + b * x + c;

                if (double.IsNaN(y) || double.IsInfinity(y))
                {
                    MessageBox.Show("Nie można narysować tego wykresu.");
                    return;
                }

                yMin = Math.Min(yMin, y);
                yMax = Math.Max(yMax, y);
            }

            double padding = (yMax - yMin) * 0.1;

            if (padding == 0)
            {
                padding = 1;
            }

            yMin -= padding;
            yMax += padding;

            double plotWidth = width - 2 * margin;
            double plotHeight = height - 2 * margin;

            double ToCanvasX(double x)
            {
                return margin + (x - xMin) /
                       (xMax - xMin) * plotWidth;
            }

            double ToCanvasY(double y)
            {
                return height - margin - (y - yMin) /
                       (yMax - yMin) * plotHeight;
            }

            for (int i = 0; i <= 10; i++)
            {
                double x = margin + i * plotWidth / 10;

                AddGraphLine(
                    x, margin, x, height - margin,
                    Brushes.Gainsboro, 1
                );

                double y = margin + i * plotHeight / 10;

                AddGraphLine(
                    margin, y, width - margin, y,
                    Brushes.Gainsboro, 1
                );
            }

            double zeroY = ToCanvasY(0);

            AddGraphLine(
                margin, zeroY, width - margin, zeroY,
                Brushes.Black, 2
            );

            if (xMin <= 0 && xMax >= 0)
            {
                double zeroX = ToCanvasX(0);

                AddGraphLine(
                    zeroX, margin, zeroX, height - margin,
                    Brushes.Black, 2
                );
            }

            Polyline curve = new Polyline();

            curve.Stroke = Brushes.RoyalBlue;
            curve.StrokeThickness = 2.5;

            for (int i = 0; i <= 300; i++)
            {
                double x = xMin + (xMax - xMin) * i / 300.0;
                double y = a * x * x + b * x + c;

                double screenX = ToCanvasX(x);
                double screenY = ToCanvasY(y);

                curve.Points.Add(new Point(screenX, screenY));
            }

            graphCanvas.Children.Add(curve);

            AddGraphMarker(
                ToCanvasX(p),
                ToCanvasY(q),
                Brushes.Orange
            );

            if (delta > 0)
            {
                double sqrtDelta = Math.Sqrt(delta);

                double x1 = (-b - sqrtDelta) / (2 * a);
                double x2 = (-b + sqrtDelta) / (2 * a);

                AddGraphMarker(
                    ToCanvasX(x1),
                    ToCanvasY(0),
                    Brushes.Green
                );

                AddGraphMarker(
                    ToCanvasX(x2),
                    ToCanvasY(0),
                    Brushes.Green
                );
            }
            else if (delta == 0)
            {
                AddGraphMarker(
                    ToCanvasX(p),
                    ToCanvasY(0),
                    Brushes.Green
                );
            }

            TextBlock xLabel = new TextBlock();
            xLabel.Text = "x";
            xLabel.FontWeight = FontWeights.Bold;

            Canvas.SetLeft(xLabel, width - margin - 10);
            Canvas.SetTop(xLabel, zeroY + 3);

            graphCanvas.Children.Add(xLabel);

            if (xMin <= 0 && xMax >= 0)
            {
                TextBlock yLabel = new TextBlock();
                yLabel.Text = "y";
                yLabel.FontWeight = FontWeights.Bold;

                Canvas.SetLeft(yLabel, ToCanvasX(0) + 5);
                Canvas.SetTop(yLabel, margin);

                graphCanvas.Children.Add(yLabel);
            }
        }

        private void AddGraphLine(
            double x1, double y1,
            double x2, double y2,
            Brush color, double thickness)
        {
            Line line = new Line();

            line.X1 = x1;
            line.Y1 = y1;
            line.X2 = x2;
            line.Y2 = y2;

            line.Stroke = color;
            line.StrokeThickness = thickness;

            graphCanvas.Children.Add(line);
        }

        private void AddGraphMarker(
            double x, double y, Brush color)
        {
            Ellipse marker = new Ellipse();

            marker.Width = 10;
            marker.Height = 10;

            marker.Fill = color;
            marker.Stroke = Brushes.Black;
            marker.StrokeThickness = 1;

            Canvas.SetLeft(marker, x - 5);
            Canvas.SetTop(marker, y - 5);

            graphCanvas.Children.Add(marker);
        }
    }
}
