﻿using System.Windows;
using System.Windows.Controls;

namespace WpfAppDelta
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void calculate(object sender, RoutedEventArgs e)
        {
            double a;
            if (string.IsNullOrWhiteSpace(txta.Text)){
                a = 0;
            }
            else{
                a = double.Parse(txta.Text);
            }
            //-----------------------------
            double b;
            if (string.IsNullOrWhiteSpace(txtb.Text)){
                b = 0;
            }
            else{
                b = double.Parse(txtb.Text);
            }
            //-----------------------------
            double c;
            if (string.IsNullOrWhiteSpace(txtc.Text)){
                c = 0;
            }
            else{
                c = double.Parse(txtc.Text);
            }
            //-----------------------------
            double Delta = b*b - 4*a*c;


            txtResult.Text = Delta.ToString();
        }
    }
}